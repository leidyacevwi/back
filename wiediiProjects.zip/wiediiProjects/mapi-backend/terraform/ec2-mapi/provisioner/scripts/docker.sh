#!/bin/bash
sudo apt-get install -y apt-transport-https ca-certificates curl gnupg
sudo wget https://download.docker.com/linux/debian/gpg
sudo apt-key add gpg
sudo echo "deb [arch=$(dpkg --print-architecture)] https://download.docker.com/linux/ubuntu $(lsb_release -cs) stable" | sudo tee -a /etc/apt/sources.list.d/docker.list
sudo apt update
sudo apt-get install -y docker-ce docker-ce-cli containerd.io docker-compose-plugin
sudo curl -SL https://github.com/docker/compose/releases/download/v2.6.0/docker-compose-linux-armv6 -o /usr/local/bin/docker-compose
#sudo curl -SL https://github.com/docker/compose/releases/download/v2.6.0/docker-compose-linux-x86_64 -o /usr/local/bin/docker-compose
sudo chmod +x /usr/local/bin/docker-compose
sudo ln -s /usr/local/bin/docker-compose /usr/bin/docker-compose
