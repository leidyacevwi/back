#!/bin/bash
sudo sed -i "/#\$nrconf{restart} = 'i';/s/.*/\$nrconf{restart} = 'a';/" /etc/needrestart/needrestart.conf
sudo hostnamectl set-hostname Mapi
sudo echo "127.0.0.1 Mapi" | sudo tee -a /etc/hosts
