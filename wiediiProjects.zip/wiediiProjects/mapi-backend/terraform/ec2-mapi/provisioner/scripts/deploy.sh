#!/bin/bash
sudo apt update
sudo apt-get -y upgrade
sudo apt-get -y install apt-transport-https
sudo apt install -y ca-certificates curl gnupg gnupg1 htop lsb-release python3-pip
# sudo mkdir -p /etc/apt/keyrings
# curl -fsSL https://download.docker.com/linux/debian/gpg | sudo gpg --dearmor -o /etc/apt/keyrings/docker.gpg
# sudo echo "deb [arch=$(dpkg --print-architecture) signed-by=/etc/apt/keyrings/docker.gpg] https://download.docker.com/linux/ubuntu $(lsb_release -cs) stable" | sudo tee /etc/apt/sources.list.d/docker.list > /dev/null
sudo source /etc/profile.d/bash_completion.sh
sudo apt update
sudo pip3 install docker
sudo pip3 install docker-compose
sudo apt update
sudo apt-get -y upgrade
sudo apt install -y nginx-extras
sudo apt install -y certbot python3-certbot-nginx
