import SystemListSearch from "./components/SystemListSearch";
import styles from "./operations.module.css";

const Coding = () => {
  return (
    <>
      <div className={styles.operations_wrapper}>
        <SystemListSearch />
      </div>
    </>
  );
};

export default Coding;
