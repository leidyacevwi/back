const Indicators = () => {
  return <div>Indicators</div>;
};

export default Indicators;
