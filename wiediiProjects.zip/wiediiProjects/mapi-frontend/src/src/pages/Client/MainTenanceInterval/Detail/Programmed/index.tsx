import SistemListSearch from "./components/SystemListSearch";

const index = () => {
  return (
    <>
      <div>
        <SistemListSearch />
      </div>
    </>
  );
};

export default index;
