import ListPartsSearch from "./components/ListFilterSearchs";

export const Lisfilters = () => {
  return (
    <>
      <ListPartsSearch />
    </>
  );
};
