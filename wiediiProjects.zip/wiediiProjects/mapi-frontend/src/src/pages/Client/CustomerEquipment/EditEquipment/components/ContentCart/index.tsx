import styles from "./contectcart.module.css";
import cart from "src/assets/cartimg.png";

const ContentCart = () => {
  return (
    <>
      <article className={styles.content_cart}>
        <div className={styles.content_img}>
          <img src={cart} alt="imagen camion" />
        </div>
        <section>
          <div>
            <label>Tipo de equipo</label>
            <select>
              <option value={""}>Selecciona un tipo de equipo</option>
            </select>
          </div>
          <div>
            <label> Marca del equipo</label>
            <select>
              <option>Selecciona una marca del equipo</option>
            </select>
          </div>
          <div>
            <label> Modelo del equipo</label>
            <select>
              <option>Selecciona el modelo del equipo</option>
            </select>
          </div>
          <div>
            <label> Año del modelo</label>
            <select>
              <option>Selecciona el año del modelo</option>
            </select>
          </div>
          <div>
            <label>Placa del equipo</label>
            <input type="text" placeholder="Escribe la placa del equipo" />
          </div>
        </section>
      </article>
    </>
  );
};

export default ContentCart;
