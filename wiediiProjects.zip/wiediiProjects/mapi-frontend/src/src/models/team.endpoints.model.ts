export class TeamEndpoints {
  static get all() {
    return "all";
  }

  static get save() {
    return "save";
  }

  static get detail() {
    return "detail";
  }

  static get delete() {
    return "delete";
  }
}
