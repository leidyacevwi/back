export class BrandEndpoints {
  static get save() {
    return "save";
  }

  static get code() {
    return "code";
  }

  static get remove_model() {
    return "remove_model";
  }

  static get remove_brand() {
    return "remove_brand";
  }

  static get models() {
    return "models";
  }
}
