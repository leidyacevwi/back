export class EquipmentEndpoints {
  static get listUserTeams() {
    return "listUserTeams";
  }

  static get download() {
    return "download";
  }

  static get teams() {
    return "teams";
  }

  static get detailUserTeam() {
    return "detailUserTeam";
  }
}
