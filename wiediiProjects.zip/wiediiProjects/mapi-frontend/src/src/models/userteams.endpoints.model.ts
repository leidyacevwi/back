export class UserTeamsEndpoints {
  
  static get list_plates() {
    return "listPlateUserTeam";
  }

  static get list_drivers() {
    return "listDriverUserTeam";
  }

}
  