export class OperationEndpoints {
  static get get_modal_data() {
    return "get_modal_data";
  }

  static get get_components() {
    return "get_components";
  }

  static get get_models() {
    return "get_models";
  }

  static get save() {
    return "save";
  }

  static get all() {
    return "all";
  }

  static get filter() {
    return "filter";
  }

  static get search_code() {
    return "search_code";
  }

  static get remove() {
    return "remove";
  }

  static get search() {
    return "search";
  }
 
  static get allData() {
    return "get_all_Data";
  }
}
