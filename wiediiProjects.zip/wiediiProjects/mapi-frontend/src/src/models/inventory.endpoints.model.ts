export class InventoryEndpoints {
    static get all() {
      return "all";
    }
  
    static get save() {
      return "save";
    }
  
    static get detail() {
      return "detail";
    }
  
    static get delete() {
      return "delete";
    }
  
    static get search() {
      return "search";
    }
  
    static get verifyRef() {
      return "verify-ref";
    }
  
  }
  