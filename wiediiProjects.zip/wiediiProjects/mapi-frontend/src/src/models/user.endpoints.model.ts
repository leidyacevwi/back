export class UserEndpoints {
  static get listPersonPage() {
    return "listPersonPage";
  }
  static get search() {
    return "search";
  }
  static get detailsUserTeam() {
    return "/detailsUserTeam";
  }
}
