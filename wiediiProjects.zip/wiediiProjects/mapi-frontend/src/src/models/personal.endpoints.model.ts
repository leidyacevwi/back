export class PersonalEndpoints {
  static get all() {
    return "all";
  }

  static get detail() {
    return "detail";
  }

  static get delete() {
    return "delete";
  }

  static get save() {
    return "save";
  }

  static get download() {
    return "download";
  }
}
