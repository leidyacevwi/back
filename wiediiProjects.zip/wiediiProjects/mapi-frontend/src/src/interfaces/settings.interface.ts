export interface SettingsState {
  translated_text: { [key: string]: string };
  currency: string;
  theme: string;
}
